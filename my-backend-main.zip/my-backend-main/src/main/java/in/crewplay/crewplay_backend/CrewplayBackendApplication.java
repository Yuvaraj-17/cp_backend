package in.crewplay.crewplay_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrewplayBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrewplayBackendApplication.class, args);
	}




}
