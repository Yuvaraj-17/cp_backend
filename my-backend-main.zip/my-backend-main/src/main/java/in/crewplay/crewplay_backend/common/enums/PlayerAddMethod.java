package in.crewplay.crewplay_backend.common.enums;

public enum PlayerAddMethod {
    MOBILE_NUMBER,
    TEAM_CODE,
    MANUAL_GUEST
}
