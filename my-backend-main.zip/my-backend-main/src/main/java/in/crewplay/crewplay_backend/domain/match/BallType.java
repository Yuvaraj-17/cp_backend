package in.crewplay.crewplay_backend.domain.match;

public enum BallType {
    TENNIS,
    LEATHER,
    CORK,
    STUMPER

}
