package in.crewplay.crewplay_backend.domain.match;

public enum BattingHand {
    LEFT,
    RIGHT
}
