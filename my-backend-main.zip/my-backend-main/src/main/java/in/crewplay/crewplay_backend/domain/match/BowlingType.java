package in.crewplay.crewplay_backend.domain.match;

public enum BowlingType {

        RIGHT_ARM_FAST,
        RIGHT_ARM_FAST_MEDIUM,
        RIGHT_ARM_MEDIUM,
        RIGHT_ARM_OFF_SPIN,
        RIGHT_ARM_LEG_SPIN,

        LEFT_ARM_FAST,
        LEFT_ARM_MEDIUM,
        LEFT_ARM_ORTHODOX,
        LEFT_ARM_WRIST_SPIN

}
