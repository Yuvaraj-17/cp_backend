package in.crewplay.crewplay_backend.domain.match;

public enum MatchType {


    LIMITED_OVERS,
    BOX_CRICKET,
    TEST
}
