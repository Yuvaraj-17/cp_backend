package in.crewplay.crewplay_backend.domain.match;

public enum PitchType {
    GREEN,
    DUSTY,
    HARD,
    MAT
}
