package in.crewplay.crewplay_backend.domain.match;

public enum TossDecision {

    BAT,
    BOWL

}
