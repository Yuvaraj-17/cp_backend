package in.crewplay.crewplay_backend.domain.match.innings;

public enum InningsStatus {

    LIVE,
    AWAITING_NEW_BATSMAN,
    AWAITING_NEW_BOWLER,
    COMPLETED

}
