package in.crewplay.crewplay_backend.domain.match.scoring.dto;

public class BowlerSelectionDTO {
    private Long userId;
    private String name;
    private String profileImageUrl;
    private String bowlingFigures; // 2-0-12-2
    private double economy;
}
