package in.crewplay.crewplay_backend.domain.match.scoring.dto;

public class PlayerSelectionDTO {
    private Long userId;
    private String name;
    private String profileImageUrl;
    private boolean isWicketKeeper;
}
