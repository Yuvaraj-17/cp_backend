package in.crewplay.crewplay_backend.domain.match.scoring.enums;

public enum BallResultType {

    NORMAL,      // Valid delivery
    WIDE,
    NO_BALL,
    DEAD_BALL
}
