package in.crewplay.crewplay_backend.domain.match.scoring.enums;

public enum ExtraType {
    WIDE,
    NO_BALL,
    BYE,
    LEG_BYE,
    PENALTY,
    NONE
}
