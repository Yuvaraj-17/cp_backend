package in.crewplay.crewplay_backend.domain.match.scoring.enums;

public enum WicketType {
    BOWLED,
    LBW,
    HIT_WICKET,
    CAUGHT,
    RUN_OUT,
    STUMPED,
    RETIRED_OUT,
    OBSTRUCTING_FIELD,
    RETIRED_HURT
}
