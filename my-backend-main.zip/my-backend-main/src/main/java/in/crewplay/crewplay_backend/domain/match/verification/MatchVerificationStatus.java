package in.crewplay.crewplay_backend.domain.match.verification;

public enum MatchVerificationStatus {
    PENDING,
    VERIFIED,
    REJECTED
}