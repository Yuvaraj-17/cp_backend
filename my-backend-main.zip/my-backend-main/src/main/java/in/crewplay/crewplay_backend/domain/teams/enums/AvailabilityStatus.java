package in.crewplay.crewplay_backend.domain.teams.enums;
public enum AvailabilityStatus {
    AVAILABLE,
    UNAVAILABLE,
    INJURED,
    PENDING
}