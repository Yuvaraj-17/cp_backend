package in.crewplay.crewplay_backend.domain.teams.enums;

public enum JoinRequestStatus {
    PENDING,
    APPROVED,
    REJECTED,
    EXPIRED,
    CANCELLED
}