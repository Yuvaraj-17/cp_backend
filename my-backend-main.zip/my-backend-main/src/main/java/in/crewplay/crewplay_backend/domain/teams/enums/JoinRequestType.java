package in.crewplay.crewplay_backend.domain.teams.enums;
public enum JoinRequestType {
    PLAYER_REQUEST,
    MANAGER_INVITE,
    LINK_JOIN,
    QR_JOIN,
    TEAM_CODE_JOIN
}