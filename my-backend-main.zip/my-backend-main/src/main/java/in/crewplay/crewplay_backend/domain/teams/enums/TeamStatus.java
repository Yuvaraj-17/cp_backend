package in.crewplay.crewplay_backend.domain.teams.enums;

public enum TeamStatus {

    TEMPORARY,   // Created inside match flow
    ACTIVE,      // Permanent team
    ARCHIVED
}
