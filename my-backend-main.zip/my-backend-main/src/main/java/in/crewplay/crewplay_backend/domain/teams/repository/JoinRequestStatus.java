package in.crewplay.crewplay_backend.domain.teams.repository;
public enum JoinRequestStatus {
    PENDING,
    APPROVED,
    REJECTED,
    EXPIRED,
    CANCELLED
}