package in.crewplay.crewplay_backend.domain.user;

public enum ExperienceLevel {
    BEGINNER,
    INTERMEDIATE,
    ADVANCED,
    PROFESSIONAL

}
