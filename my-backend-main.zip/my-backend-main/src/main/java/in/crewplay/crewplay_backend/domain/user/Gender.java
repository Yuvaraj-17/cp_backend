package in.crewplay.crewplay_backend.domain.user;

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}