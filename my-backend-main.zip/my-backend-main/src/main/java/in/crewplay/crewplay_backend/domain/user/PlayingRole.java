package in.crewplay.crewplay_backend.domain.user;

public enum PlayingRole {
    WICKET_KEEPER,
    OPENING_BATSMAN,
    MIDDLE_ORDER_BATSMAN,
    LOWER_ORDER_BATSMAN,
    ALL_ROUNDER
}
