package in.crewplay.crewplay_backend.domain.user;

public enum Role {
    PLAYER,
    SCORER,
    TEAM_MANAGER
}