package in.crewplay.crewplay_backend.match_setup.Controller;

public class MatchSetupController {
}
