package in.crewplay.crewplay_backend.match_setup.Repository;

public class MatchSquadRepository {
}
