package in.crewplay.crewplay_backend.match_setup.dto.request;

public class CreateQuickMatchRequest {
}
