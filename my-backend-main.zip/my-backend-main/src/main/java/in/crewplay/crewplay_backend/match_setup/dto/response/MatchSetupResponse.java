package in.crewplay.crewplay_backend.match_setup.dto.response;

public class MatchSetupResponse {
}
