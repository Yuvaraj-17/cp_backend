package in.crewplay.crewplay_backend.team.dto.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class VerifyCaptainRequest {
    private String captainEmail;
}
