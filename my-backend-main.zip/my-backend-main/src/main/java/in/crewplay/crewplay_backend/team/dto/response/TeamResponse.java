package in.crewplay.crewplay_backend.team.dto.response;

public class TeamResponse {
}
