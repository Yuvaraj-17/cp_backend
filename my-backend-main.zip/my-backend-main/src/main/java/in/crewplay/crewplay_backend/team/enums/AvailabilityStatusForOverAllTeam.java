package in.crewplay.crewplay_backend.team.enums;
public enum AvailabilityStatusForOverAllTeam {
    AVAILABLE,
    UNAVAILABLE,
    INJURED,
    PENDING
}