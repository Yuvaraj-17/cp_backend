package in.crewplay.crewplay_backend.team.enums;

public enum JoinRequestStatusForOverAllTeam {
    PENDING,
    APPROVED,
    REJECTED,
    EXPIRED,
    CANCELLED
}