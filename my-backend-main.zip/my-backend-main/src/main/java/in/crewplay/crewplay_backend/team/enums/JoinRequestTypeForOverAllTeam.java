package in.crewplay.crewplay_backend.team.enums;
public enum JoinRequestTypeForOverAllTeam {
    PLAYER_REQUEST,
    MANAGER_INVITE,
    LINK_JOIN,
    QR_JOIN,
    TEAM_CODE_JOIN
}