package in.crewplay.crewplay_backend.team.enums;

public enum TeamStatusForOverAllTeam {

    TEMPORARY,   // Created inside match flow
    ACTIVE,      // Permanent team
    ARCHIVED
}
