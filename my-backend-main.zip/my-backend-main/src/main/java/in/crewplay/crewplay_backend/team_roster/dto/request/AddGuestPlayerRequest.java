package in.crewplay.crewplay_backend.team_roster.dto.request;

public class AddGuestPlayerRequest {
}
