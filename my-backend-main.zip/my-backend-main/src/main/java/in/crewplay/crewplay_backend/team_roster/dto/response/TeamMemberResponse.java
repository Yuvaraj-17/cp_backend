package in.crewplay.crewplay_backend.team_roster.dto.response;

public class TeamMemberResponse {
}
