package in.crewplay.crewplay_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrewplayBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
